#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      hellrungj
#
# Created:     06/10/2014
# Copyright:   (c) hellrungj 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

class Map_Exception(Exception):
    '''Create a Python class to enable meaningful error messages on exceptions.'''
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value) # allows a meaningful error message to be displayed

class Map:

    def __init__ (self, fileame):
        self.readingfile = filename
        self.width=0
        self.height=0
        self.textslist=[]
        self.ascii=""
        self.magic="P3" # ppm file type
        self.row = 0
        self.column = 0

    def Map_partition(self,strng,ch):
        '''Given input parameters: strng, the string to partition and ch, the character to use as the delimiter
            Returns a triple with all characters before the delimiter, the delimiter iteself if present
            and all of the characters after the delimiter (if any)'''
        if (ch in strng):
            i = strng.index(ch)
            return (strng[0:i],strng[i],strng[i+1:])
        else:
            return (strng,None,None)

    def MAP_clean(self,strng):
        '''removes all singleline comments present in the input parameter string strng
        Returns a string with all characters after the comment character removed.
        All white space at the end is also removed, including the newline and linefeed characters.'''
        (retval,junk1,junk2) = self.Map_partition(strng,"#")
        return retval.rstrip(" \t\n\r")

    def Translate_FiletoTexts(self):
        """Reads file and translates to a string in which we can use."""
        infile = open(self.readingfile,"r")

        # Read the magic number out of the top of the file and verify that we are
        # reading from an ASCII PPM-P3 file
        tmpln=infile.readline()
        self.ascii+=tmpln
        self.magic = self.MAP_clean(tmpln)

        # Get the image dimensions
        tmpln=infile.readline()
        while tmpln[0]=='#': #dump full comment lines
            tmpln=infile.readline()
        self.ascii+=tmpln
        imgdimensions = self.MAP_clean(tmpln)

        (weight, sep, height) = self.Map_partition(imgdimensions," ")
        self.width=int(width)
        self.height=int(height)
        #--------------------------------
        #error message
        if (self.width <= 0) or (self.height <= 0):
            raise Map_Exception, "The file being loaded does not appear to have valid dimensions (" + str(width) + " x " + str(height) + ")"

        def Move_Along(self): #compiles everything
            """Pre: takes self permater.
            Checks if user's character can move to the next spot by using "Movement"
            and if so moves the char "M" and adds a "stars" to its past location
            Post: makes a star for the location"""
            #----------
            #Starts the player location is the cave

            pass

        def Rope(self): #give us a life line
            """adds a "stars" to the list for the player past location"""
            pass

        def Movement(self): # Moves the char
            """Makes the states for the player"""
            #-------
            #North

        def Money(self): # add treasure to the player money score
            """Keeps a list of how many treasure the player has"""
            pass

        def Treasure(self): # looks for "T"
            """Checks for treasure and adds it the player money"""
            pass

        def Lost(self):
            """checks if the players is losted. If the player finds his/her self look back in the same dicidtion too many time than game over"""
            pass

        def back_tracking(self):
            """check if the player is lost and removes the stars while moveing the player back"""
            pass

        def display_map(self):
            """show the player the map"""
            pass



