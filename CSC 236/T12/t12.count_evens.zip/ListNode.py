# ListNode.py
class ListNode(object):
    
    def __init__(self, item = None, link = None):

        '''creates a ListNode with the specified data value and link
        post: creates a ListNode with the specified data value and link'''
        
        self.item = item
        self.link = link

