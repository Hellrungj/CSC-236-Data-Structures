#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Brandon
#
# Created:     26/10/2014
# Copyright:   (c) Brandon 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from Tree import tree
import sys
def make_tree():
    "Sets up the tree"
    filename=raw_input("Input file: ") #get file name
    open_file = open(filename, 'r') #open file
    question = tree()
    current_node = question
    end = 0 #while loop breaker breaker

    while end == 0:
        line = open_file.readline()
        if line == " ":
            return False #ends the function
        if line == "Question:\n": #serches for question
            line = open_file.readline() #gets the next line
            current_node.data = line #makes it the root

            end = 1

    end = 0
    while end == 0:
        line = open_file.readline()
        if line == "":
            end = 1 #ends the while loop
        if line == "Question:\n":
            line = open_file.readline()
            current_node.right = tree(line)#creats the data and adress for the right part of the tree
            current_node = current_node.right#holds the current line

        if current_node.left != None:
            if line == "Guess:\n":#serches for guess
                line = open_file.readline() #gets the guess
                current_node.right =  tree()#creats the data and adress for the right part of the tree
                current_node.right.data = line
        if line == "Guess:\n":
            line = open_file.readline()
            current_node.left = tree()#creats the letf part of the tree and creats the data and adress for the left part of the tree
            current_node.left.data = line
    return question #ends function
def main():
    "calls make the make tree part and the questions asking"
    b=0
    while True:
        question = make_tree()#calls make tree function
        current_node = question #sets current_node to equal question
        while True:
            if current_node.right == None:
                print current_node.data
                return False
            user_input = str(raw_input(current_node.data)) #input yes or no for question
            if user_input== 'n' or user_input == 'no': #if no
                user_input = str(raw_input("Is you animal " +current_node.left.data+"?"))#input yes or no for question
                if user_input == 'y' or user_input == 'yes': #if yes
                    user_input=str(raw_input("I win! Do you wish to play again?"))#input yes or no for question
                    if user_input == 'y' or user_input == 'yes':#if yes
                        break #just this while loop
                    if user_input== 'n' or user_input == 'no':#if no
                        sys.exit()#ends program
                elif user_input=='n' or user_input == 'no': #if no
                    user_input1= str(raw_input("What is your animal?"))#gets now animal
                    user_input2= str(raw_input("What is a question to tell the diffrience?"))#gets new question
                    file.write("Question:\n")#writes in game.in
                    file.write(user_input2 +"\n")#writes in game.in
                    file.write("Guess:\n")#writes in game.in
                    file.write(user_input1 +"\n")#writes in game.in
                    sys.exit()#end program
            elif user_input == 'y' or user_input == 'yes':#if yes from the first question
                current_node = current_node.right
                b+=1
                if b>1:
                    user_input = str(raw_input("Is you animal " +current_node.right.data+"?"))
                    if user_input == 'y' or user_input == 'yes':
                        user_input=str(raw_input("I win! Do you wish to play again?"))
                        if user_input == 'y' or user_input == 'yes':
                            break
                        if user_input== 'n' or user_input == 'no':
                            sys.exit()
                    if user_input=='n' or user_input == 'no':
                        user_input1= str(raw_input("What is your animal?"))
                        user_input2= str(raw_input("What is a question to tell the diffrience?"))
                        file.write("Question:\n")
                        file.write(user_input2 +"\n")
                        file.write("Guess:\n")
                        file.write(user_input1 +"\n")
                        sys.exit()



if __name__ == '__main__':
    main()
