#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Brandon
#
# Created:     26/10/2014
# Copyright:   (c) Brandon 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

class tree:
    def __init__(self, data=None, left=None, right=None):
        "post: sets up the class varables"
        self.data = data
        self.left = left
        self.right = right

    def add_question(self, right):
        "post: sets the question"
        self.right = tree()

    def add_left(self, left):
        "post: sets the left guess"
        self.left = left

    def add_right(self, right):
        "post: sets the right guess"
        self.right = right

