#-------------------------------------------------------------------------------
# Name:        John Hellrung &
# Purpose:
#
# Author:      hellrungj
#
# Created:     13/10/2014
# Copyright:   (c) hellrungj 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from Game import Map
#--------------------
# cave_sample.txt
# map1.txt
# map2.txt
# map3.txt
#----------------
def main():
    Game = Map()
    Game.run()

if __name__ == '__main__':
    main()
